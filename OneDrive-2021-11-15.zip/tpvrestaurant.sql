-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  ven. 12 nov. 2021 à 12:29
-- Version du serveur :  8.0.18
-- Version de PHP :  7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `tpvrestaurant`
--

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

DROP TABLE IF EXISTS `article`;
CREATE TABLE IF NOT EXISTS `article` (
  `idArticle` int(11) NOT NULL AUTO_INCREMENT,
  `designationArticle` varchar(45) DEFAULT NULL,
  `prixArticle` decimal(10,0) DEFAULT NULL,
  `photoArticle` varchar(45) DEFAULT NULL,
  `idCategorieArticleFK` int(11) DEFAULT NULL,
  PRIMARY KEY (`idArticle`),
  KEY `fk_Article_CategorieArticle1_idx` (`idCategorieArticleFK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `categoriearticle`
--

DROP TABLE IF EXISTS `categoriearticle`;
CREATE TABLE IF NOT EXISTS `categoriearticle` (
  `idCatArticle` int(11) NOT NULL AUTO_INCREMENT,
  `libelleCatArticle` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idCatArticle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

DROP TABLE IF EXISTS `commande`;
CREATE TABLE IF NOT EXISTS `commande` (
  `numCommande` int(11) NOT NULL AUTO_INCREMENT,
  `termine` tinyint(4) DEFAULT NULL,
  `idServeurFK` int(11) NOT NULL,
  `numTableeFK` int(11) NOT NULL,
  PRIMARY KEY (`numCommande`),
  KEY `fk_Commande_Serveur_idx` (`idServeurFK`),
  KEY `fk_Commande_tablee1_idx` (`numTableeFK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `qtearticle`
--

DROP TABLE IF EXISTS `qtearticle`;
CREATE TABLE IF NOT EXISTS `qtearticle` (
  `Commande_numCommande` int(11) NOT NULL,
  `idArticle` int(11) NOT NULL,
  `Qte` int(11) DEFAULT NULL,
  PRIMARY KEY (`Commande_numCommande`,`idArticle`),
  KEY `fk_Commande_has_Article_Article1_idx` (`idArticle`),
  KEY `fk_Commande_has_Article_Commande1_idx` (`Commande_numCommande`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `serveur`
--

DROP TABLE IF EXISTS `serveur`;
CREATE TABLE IF NOT EXISTS `serveur` (
  `idServeur` int(11) NOT NULL AUTO_INCREMENT,
  `nomServeur` varchar(45) DEFAULT NULL,
  `prenomServeur` varchar(45) DEFAULT NULL,
  `actif` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`idServeur`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `tablee`
--

DROP TABLE IF EXISTS `tablee`;
CREATE TABLE IF NOT EXISTS `tablee` (
  `numTablee` int(11) NOT NULL AUTO_INCREMENT,
  `nbPlaceTablee` int(45) DEFAULT NULL,
  PRIMARY KEY (`numTablee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `article`
--
ALTER TABLE `article`
  ADD CONSTRAINT `fk_Article_CategorieArticle1` FOREIGN KEY (`idCategorieArticleFK`) REFERENCES `categoriearticle` (`idCatArticle`);

--
-- Contraintes pour la table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `fk_Commande_Serveur` FOREIGN KEY (`idServeurFK`) REFERENCES `serveur` (`idServeur`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_Commande_tablee1` FOREIGN KEY (`numTableeFK`) REFERENCES `tablee` (`numTablee`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `qtearticle`
--
ALTER TABLE `qtearticle`
  ADD CONSTRAINT `fk_Commande_has_Article_Article1` FOREIGN KEY (`idArticle`) REFERENCES `article` (`idArticle`),
  ADD CONSTRAINT `fk_Commande_has_Article_Commande1` FOREIGN KEY (`Commande_numCommande`) REFERENCES `commande` (`numCommande`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
